-- ============================================
-- AÑADIR PROPIEDADES DE PRUEBA PARA SEMÁFORO
-- ============================================
-- Este script añade propiedades en las fases:
-- - "Inquilino aceptado"
-- - "Pendiente de trámites"
-- Con diferentes valores de days_to_lease_property para probar el semáforo:
--   🔴 Rojo: days_to_lease_property > 35
--   🟡 Amarillo: days_to_lease_property >= 25 && <= 35
--   ⚪ Sin borde: days_to_lease_property < 25

-- ============================================
-- PASO 1: Añadir propiedades en "Inquilino aceptado"
-- ============================================
INSERT INTO properties (
  id,
  property_ref_id, 
  address, 
  city, 
  area_cluster, 
  current_stage,
  days_in_stage,
  property_type, 
  property_manager, 
  writing_date, 
  visit_date, 
  days_to_visit, 
  days_to_start, 
  is_expired, 
  needs_update,
  days_to_lease_property,
  publication_date
)
VALUES
  -- 🔴 Borde ROJO (days_to_lease_property > 35)
  (gen_random_uuid(), 'PROP-IA-001', 'Calle Goya 45, 3º A', 'Madrid', 'Madrid', 'Inquilino aceptado', 5, 'light', 'Almasur', NULL, NULL, NULL, NULL, false, false, 40, '2024-11-15'),
  (gen_random_uuid(), 'PROP-IA-002', 'Avenida de la Castellana 120, 4º B', 'Madrid', 'Madrid', 'Inquilino aceptado', 8, 'medium', 'JReformas', NULL, NULL, NULL, NULL, false, false, 45, '2024-11-10'),
  (gen_random_uuid(), 'PROP-IA-003', 'Calle Velázquez 80, 2º C', 'Madrid', 'Madrid', 'Inquilino aceptado', 12, 'light', 'Pedro', NULL, NULL, NULL, NULL, false, false, 50, '2024-11-05'),
  
  -- 🟡 Borde AMARILLO (days_to_lease_property >= 25 && <= 35)
  (gen_random_uuid(), 'PROP-IA-004', 'Calle Serrano 150, 5º D', 'Madrid', 'Madrid', 'Inquilino aceptado', 3, 'light', 'Almasur', NULL, NULL, NULL, NULL, false, false, 25, '2024-11-20'),
  (gen_random_uuid(), 'PROP-IA-005', 'Avenida de América 200, 1º E', 'Madrid', 'Madrid', 'Inquilino aceptado', 6, 'medium', 'César', NULL, NULL, NULL, NULL, false, false, 30, '2024-11-15'),
  (gen_random_uuid(), 'PROP-IA-006', 'Calle Príncipe de Vergara 100, 3º F', 'Madrid', 'Madrid', 'Inquilino aceptado', 9, 'light', 'JReformas', NULL, NULL, NULL, NULL, false, false, 35, '2024-11-10'),
  
  -- ⚪ Sin borde (days_to_lease_property < 25)
  (gen_random_uuid(), 'PROP-IA-007', 'Calle Claudio Coello 60, 2º G', 'Madrid', 'Madrid', 'Inquilino aceptado', 2, 'light', 'Almasur', NULL, NULL, NULL, NULL, false, false, 10, '2024-11-25'),
  (gen_random_uuid(), 'PROP-IA-008', 'Avenida de Brasil 30, 4º H', 'Madrid', 'Madrid', 'Inquilino aceptado', 4, 'medium', 'Pedro', NULL, NULL, NULL, NULL, false, false, 15, '2024-11-20'),
  (gen_random_uuid(), 'PROP-IA-009', 'Calle Mayor 200, 1º I', 'Madrid', 'Madrid', 'Inquilino aceptado', 7, 'light', 'César', NULL, NULL, NULL, NULL, false, false, 20, '2024-11-15');

-- ============================================
-- PASO 2: Añadir propiedades en "Pendiente de trámites"
-- ============================================
INSERT INTO properties (
  id,
  property_ref_id, 
  address, 
  city, 
  area_cluster, 
  current_stage,
  days_in_stage,
  property_type, 
  property_manager, 
  writing_date, 
  visit_date, 
  days_to_visit, 
  days_to_start, 
  is_expired, 
  needs_update,
  days_to_lease_property,
  publication_date
)
VALUES
  -- 🔴 Borde ROJO (days_to_lease_property > 35)
  (gen_random_uuid(), 'PROP-PT-001', 'Calle Gran Vía 200, 6º A', 'Madrid', 'Madrid', 'Pendiente de trámites', 10, 'light', 'Almasur', NULL, NULL, NULL, NULL, false, false, 42, '2024-10-20'),
  (gen_random_uuid(), 'PROP-PT-002', 'Avenida Diagonal 300, 3º B', 'Barcelona', 'Barcelona', 'Pendiente de trámites', 15, 'medium', 'JReformas', NULL, NULL, NULL, NULL, false, false, 48, '2024-10-15'),
  (gen_random_uuid(), 'PROP-PT-003', 'Calle Paseo de Gracia 150, 5º C', 'Barcelona', 'Barcelona', 'Pendiente de trámites', 20, 'light', 'César', NULL, NULL, NULL, NULL, false, false, 55, '2024-10-10'),
  
  -- 🟡 Borde AMARILLO (days_to_lease_property >= 25 && <= 35)
  (gen_random_uuid(), 'PROP-PT-004', 'Calle Rambla Catalunya 80, 2º D', 'Barcelona', 'Barcelona', 'Pendiente de trámites', 8, 'light', 'Almasur', NULL, NULL, NULL, NULL, false, false, 27, '2024-10-28'),
  (gen_random_uuid(), 'PROP-PT-005', 'Avenida de la Paz 50, 4º E', 'Barcelona', 'Barcelona', 'Pendiente de trámites', 12, 'medium', 'Pedro', NULL, NULL, NULL, NULL, false, false, 32, '2024-10-23'),
  (gen_random_uuid(), 'PROP-PT-006', 'Calle Balmes 100, 1º F', 'Barcelona', 'Barcelona', 'Pendiente de trámites', 18, 'light', 'JReformas', NULL, NULL, NULL, NULL, false, false, 35, '2024-10-20'),
  
  -- ⚪ Sin borde (days_to_lease_property < 25)
  (gen_random_uuid(), 'PROP-PT-007', 'Calle Provença 200, 3º G', 'Barcelona', 'Barcelona', 'Pendiente de trámites', 5, 'light', 'Almasur', NULL, NULL, NULL, NULL, false, false, 12, '2024-11-03'),
  (gen_random_uuid(), 'PROP-PT-008', 'Avenida Meridiana 150, 5º H', 'Barcelona', 'Barcelona', 'Pendiente de trámites', 7, 'medium', 'César', NULL, NULL, NULL, NULL, false, false, 18, '2024-10-28'),
  (gen_random_uuid(), 'PROP-PT-009', 'Calle Muntaner 80, 2º I', 'Barcelona', 'Barcelona', 'Pendiente de trámites', 14, 'light', 'Pedro', NULL, NULL, NULL, NULL, false, false, 22, '2024-10-23');

-- ============================================
-- PASO 3: Verificar propiedades insertadas
-- ============================================
SELECT 
  property_ref_id,
  address,
  current_stage,
  days_to_lease_property,
  publication_date,
  CASE 
    WHEN days_to_lease_property > 35 THEN '🔴 Debería mostrar borde ROJO'
    WHEN days_to_lease_property >= 25 AND days_to_lease_property <= 35 THEN '🟡 Debería mostrar borde AMARILLO'
    WHEN days_to_lease_property < 25 THEN '⚪ Sin borde (normal)'
    ELSE '❓ Sin valor'
  END AS estado_semaforo
FROM properties
WHERE property_ref_id LIKE 'PROP-IA-%' OR property_ref_id LIKE 'PROP-PT-%'
ORDER BY current_stage, days_to_lease_property DESC;

-- ============================================
-- PASO 4: Estadísticas por fase
-- ============================================
SELECT 
  current_stage,
  COUNT(*) as total_propiedades,
  COUNT(CASE WHEN days_to_lease_property > 35 THEN 1 END) as borde_rojo,
  COUNT(CASE WHEN days_to_lease_property >= 25 AND days_to_lease_property <= 35 THEN 1 END) as borde_amarillo,
  COUNT(CASE WHEN days_to_lease_property < 25 THEN 1 END) as sin_borde
FROM properties
WHERE current_stage IN ('Inquilino aceptado', 'Pendiente de trámites')
  AND (property_ref_id LIKE 'PROP-IA-%' OR property_ref_id LIKE 'PROP-PT-%')
GROUP BY current_stage;

-- ============================================
-- ELIMINAR PROPIEDADES DE PRUEBA (cuando quieras limpiar)
-- ============================================
-- DELETE FROM properties WHERE property_ref_id LIKE 'PROP-IA-%' OR property_ref_id LIKE 'PROP-PT-%';
